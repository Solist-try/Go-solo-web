<?php
$pageTitle = ($person['display_name'] ?: 'Profile') . ' · ' . site_text('site_title');
$name = $person['display_name'] ?: 'A member';
?>
<section class="frame section">
  <p class="kicker"><?= $isSelf ? 'My Garden' : 'A garden' ?></p>
  <h1><?= e($name) ?></h1>
  <?php if (!empty($person['avatar_path'])): ?>
    <img class="avatar" src="<?= e(media($person['avatar_path'])) ?>" alt="">
  <?php endif; ?>
  <?php if ($showLocation && trim((string) $person['location']) !== ''): ?>
    <p class="soft"><?= e($person['location']) ?></p>
  <?php endif; ?>
  <?php if ($isSelf): ?>
    <p class="row-actions">
      <a class="button quiet small" href="<?= e(url('/profile/edit')) ?>">Tend this garden</a>
      <a class="button quiet small" href="<?= e(url('/notices')) ?>">Notes</a>
      <a class="button quiet small" href="<?= e(url('/account')) ?>">Account</a>
    </p>
  <?php endif; ?>

  <h2>Bio</h2>
  <?php if (trim((string) $person['bio']) === ''): ?>
    <p class="soft">A few words can wait.</p>
  <?php else: ?>
    <?= paragraphs((string) $person['bio']) ?>
  <?php endif; ?>

  <?php if ($isSelf && $matches): ?>
    <h2>Someone on a similar path</h2>
    <?php foreach ($matches as $match): ?>
      <article class="card sage">
        <p>A steward suggested <?= e($match['other_name']) ?> for this stretch. You can take your time.</p>
        <p><a href="<?= e(url('/members/' . $match['other_id'])) ?>"><?= e($match['other_name']) ?></a></p>
        <?php if ($match['note']): ?><p><?= e($match['note']) ?></p><?php endif; ?>
        <?php foreach ($sameNotes[$match['id']] ?? [] as $note): ?>
          <p><strong><?= e($note['display_name'] ?: 'A member') ?></strong> <span class="soft"><?= e(nice_date($note['created_at'])) ?></span><br><?= e($note['body']) ?></p>
        <?php endforeach; ?>
        <form method="post" action="<?= e(url('/notes')) ?>">
          <?= csrf_field() ?>
          <input type="hidden" name="context_type" value="same">
          <input type="hidden" name="context_id" value="<?= e((string) $match['id']) ?>">
          <label><span>A note, whenever you want</span><textarea name="body" maxlength="2000"></textarea></label>
          <button type="submit">Leave the note</button>
        </form>
      </article>
    <?php endforeach; ?>
  <?php endif; ?>

  <?php if ($isSelf && $skillLinks): ?>
    <h2>A skill swap</h2>
    <?php foreach ($skillLinks as $link): ?>
      <article class="card clay">
        <p>A steward connected you with <?= e($link['other_name']) ?> for a skill swap. You can take your time.</p>
        <?php if ($link['title']): ?><p><?= e($link['title']) ?></p><?php endif; ?>
        <p><a href="<?= e(url('/members/' . $link['other_id'])) ?>"><?= e($link['other_name']) ?></a></p>
        <?php foreach ($skillNotes[$link['id']] ?? [] as $note): ?>
          <p><strong><?= e($note['display_name'] ?: 'A member') ?></strong> <span class="soft"><?= e(nice_date($note['created_at'])) ?></span><br><?= e($note['body']) ?></p>
        <?php endforeach; ?>
        <form method="post" action="<?= e(url('/notes')) ?>">
          <?= csrf_field() ?>
          <input type="hidden" name="context_type" value="skill">
          <input type="hidden" name="context_id" value="<?= e((string) $link['id']) ?>">
          <label><span>A note, whenever you want</span><textarea name="body" maxlength="2000"></textarea></label>
          <button type="submit">Leave the note</button>
        </form>
      </article>
    <?php endforeach; ?>
  <?php endif; ?>

  <h2>Waypoints</h2>
  <?php if (!$waypoints): ?><p class="soft">No chair chosen yet.</p><?php else: ?>
    <ul class="chips">
      <?php foreach ($waypoints as $waypoint): ?>
        <li><a href="<?= e(url('/waypoints/' . $waypoint['slug'])) ?>"><?= e($waypoint['title']) ?></a></li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>

  <h2>Seeds I'm Growing</h2>
  <?php if (!$growing && !$planted): ?><p class="soft">Nothing planted yet.</p><?php endif; ?>
  <ul class="list">
    <?php foreach ($planted as $seed): ?>
      <li><a href="<?= e(url('/seeds/' . $seed['slug'])) ?>"><?= e($seed['title']) ?></a></li>
    <?php endforeach; ?>
    <?php foreach ($growing as $seed): ?>
      <li><?= e($seed['title']) ?><?php if ($seed['status'] === 'resting'): ?> <span class="soft">· resting</span><?php endif; ?><?php if (!empty($seed['looking_for_support'])): ?> <span class="soft">· open to help</span><?php endif; ?></li>
    <?php endforeach; ?>
  </ul>

  <h2>Seeds I'd Like Help Growing</h2>
  <?php if (!$helpRequests): ?><p class="soft">No requests yet.</p><?php else: ?>
    <ul class="chips"><?php foreach ($helpRequests as $title): ?><li><?= e($title) ?></li><?php endforeach; ?></ul>
  <?php endif; ?>

  <h2>Seeds I'm Happy To Help Plant</h2>
  <?php if (!$helpOffers): ?><p class="soft">No offers yet.</p><?php else: ?>
    <ul class="chips"><?php foreach ($helpOffers as $title): ?><li><?= e($title) ?></li><?php endforeach; ?></ul>
  <?php endif; ?>

  <h2>Support Preferences</h2>
  <?php if (!$supports): ?><p class="soft">Still finding a rhythm.</p><?php else: ?>
    <ul class="chips"><?php foreach ($supports as $choice): ?><li><?= e($choice) ?></li><?php endforeach; ?></ul>
  <?php endif; ?>

  <h2>Contact Frequency</h2>
  <p><?= e($person['contact_frequency'] ?: 'Whenever it suits.') ?></p>

  <h2>Check-In Style</h2>
  <p><?= e($person['check_in_style'] ?: 'Any way that feels easy.') ?></p>

  <h2>Recent Out There Stories</h2>
  <?php if (!$stories): ?><p class="soft">No stories brought back yet.</p><?php else: ?>
    <ul class="list">
      <?php foreach ($stories as $story): ?>
        <li>
          <a href="<?= e(url('/out-there/' . $story['id'])) ?>"><?= e($story['title']) ?></a>
          <span class="soft"> · <?= e(nice_date($story['created_at'])) ?></span>
          <?php if (!empty($story['hidden'])): ?><span class="soft"> · hidden</span><?php endif; ?>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>

  <?php if ($isSelf && $warnings): ?>
    <h2>A note from the steward</h2>
    <?php foreach ($warnings as $warning): ?>
      <article class="card clay">
        <p><?= e($warning['note']) ?></p>
        <p class="soft"><?= e(nice_date($warning['created_at'])) ?></p>
      </article>
    <?php endforeach; ?>
  <?php endif; ?>

  <?php if ($currentUser && !$isSelf): ?>
    <form method="post" action="<?= e(url('/members/' . $person['id'] . '/report')) ?>">
      <?= csrf_field() ?>
      <label><span>If something here is not right, tell the steward</span><textarea name="reason" maxlength="1000" required></textarea></label>
      <button class="quiet small" type="submit">Send a report</button>
    </form>
  <?php endif; ?>
</section>
