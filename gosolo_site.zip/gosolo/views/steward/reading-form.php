<?php $pageTitle = 'Article · Steward Desk'; $desk = 'reading'; include __DIR__ . '/open.php'; ?>
<h1><?= !empty($article['id']) ? 'Edit article' : 'Create article' ?></h1>
<form method="post" action="<?= e(url('/steward/reading/save')) ?>" enctype="multipart/form-data">
  <?= csrf_field() ?>
  <input type="hidden" name="id" value="<?= e((string) ($article['id'] ?? 0)) ?>">
  <label><span>Title</span><input type="text" name="title" maxlength="180" required value="<?= e($article['title'] ?? '') ?>"></label>
  <label><span>Slug</span><input type="text" name="slug" maxlength="120" value="<?= e($article['slug'] ?? '') ?>"></label>
  <label><span>Category</span>
    <select name="category_id">
      <?php foreach ($categories as $category): ?>
        <option value="<?= e((string) $category['id']) ?>"<?= (int) ($article['category_id'] ?? 0) === (int) $category['id'] ? ' selected' : '' ?>><?= e($category['title']) ?></option>
      <?php endforeach; ?>
    </select>
  </label>
  <label><span>Standfirst</span><input type="text" name="standfirst" maxlength="255" value="<?= e($article['standfirst'] ?? '') ?>"></label>
  <?php
    $editor = [
        'embedded' => true,
        'headings' => true,
        'body' => (string) ($article['body'] ?? ''),
        'body_label' => 'Article',
        'help' => 'The title above stays the main heading. Medium and small headings are sections inside the piece.',
    ];
    include __DIR__ . '/../partials/editor.php';
  ?>
  <label><span>Image</span><input type="file" name="image" accept="image/jpeg,image/png,image/webp,image/gif"></label>
  <?php if (function_exists('pin_ready') && pin_ready()): ?>
    <label>
      <input type="checkbox" name="featured" value="1"<?= !empty($article['featured']) ? ' checked' : '' ?>>
      <?= e(site_text('pin_feature')) ?>
    </label>
    <label><span><?= e(site_text('pin_order')) ?></span>
      <input type="number" name="featured_order" value="<?= e((string) ($article['featured_order'] ?? 0)) ?>">
    </label>
    <p class="soft"><?= e(site_text('pin_feature_note')) ?></p>
  <?php endif; ?>
  <label><span>Status</span>
    <select name="status">
      <option value="draft"<?= ($article['status'] ?? '') === 'draft' ? ' selected' : '' ?>>Draft</option>
      <option value="published"<?= ($article['status'] ?? 'published') === 'published' ? ' selected' : '' ?>>Published</option>
    </select>
  </label>
  <button type="submit">Save article</button>
</form>
<?php if (!empty($article['id'])): ?>
  <form method="post" action="<?= e(url('/steward/reading/delete')) ?>">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= e((string) $article['id']) ?>">
    <label><input type="checkbox" name="yes" value="1"> Yes, delete this article</label>
    <button class="quiet" type="submit">Delete article</button>
  </form>
<?php endif; ?>
<?php include __DIR__ . '/close.php'; ?>
